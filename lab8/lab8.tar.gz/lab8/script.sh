#!/bin/bash
module load libraries/openmpi-1.6-gcc-4.7.0
mpirun -2 ./a.out