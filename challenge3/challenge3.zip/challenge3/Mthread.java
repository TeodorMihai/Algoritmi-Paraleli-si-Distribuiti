package challenge3;

import java.util.concurrent.Semaphore;

public class Mthread extends Thread {

	
	Semaphore[] s;
	Semaphore opus;
	
	Mthread(Semaphore[] _s, Semaphore _opus) {
		s  = _s;
		opus = _opus;
	}
	
	
	@Override
	public void run() {
			
		Person p = null;
		
		
		while(true) {
		
			synchronized (Main.o1) {
				
				if(Main.q.isEmpty() == true) return ;
				
				p = Main.q.poll();
				
			}
			
			//planificare la intrare
			synchronized (Main.o1) {
				
				while(s[p.direction].availablePermits() == 0);
				synchronized (Main.o2) {
					
					
					try {
						s[p.direction].acquire();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
					
				
					if(s[p.direction].availablePermits() == 4) {//daca e primul
						while(opus.availablePermits() == 0);
						try {
							opus.acquire();
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					
				
			}
			
			//pentru testare , nu tine de logica
			synchronized (Mthread.class) {
				
				if(p.direction == 0) {
					System.out.println("--> start");
					Main.check++;
				}
				else {
					if(Main.check != 0)
						System.out.println("problem" + Main.check);
					System.out.println("<-- start");
				}
				
			}
		
			
			//traversarea paralela, some work
			try {
				Thread.sleep(p.timeOnPath);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			//planificare la iesire
			synchronized (Mthread.class) {
				
				synchronized (Main.o2) {
	
					s[p.direction].release();
					
					
					if(s[p.direction].availablePermits() == 5)
						opus.release();
					
					if(p.direction == 0) {
						System.out.println("--> finish");
						Main.check--;
						
					}
					else
					System.out.println("<-- finish");
				}
			
					
				
			}
			
		
		}
		
		
		
	}
}
