package challenge3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.Semaphore;

public class Main {

	
	static int N;
	static final int persons = 1000;
	static Queue<Person> q = new LinkedList<Person>();
	static int check = 0;
	static Object o1 = new Object();
	static Object o2 = new Object();
	
	public static void main(String[] args) {
		
		N = 4;
		Random r = new Random();
		Mthread[] threads = new Mthread[N];
		Semaphore[] s = new Semaphore[2];
		Semaphore opus = new Semaphore(1);
		
		s[0] = new Semaphore(5);
		s[1] = new Semaphore(5);
		
		
		
		for(int i = 0 ; i < N; ++i)
			threads[i] = new Mthread(s, opus);
		
		for(int i = 0 ; i < persons ; ++i)
			q.add(new Person(r.nextInt(2), r.nextInt(2)));
		
		for(int i = 0 ; i < N; ++i)
			threads[i].start();
		
		
		for(int i = 0 ; i < N; ++i)
			try {
				threads[i].join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
	}

}
