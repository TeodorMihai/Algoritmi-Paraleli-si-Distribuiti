package challenge3;

public class Person {
	
	int direction;
	int timeOnPath;
	
	Person(int direction, int timeOnPath) {
		this.direction = direction;
		this.timeOnPath = timeOnPath;
		
	}

}
